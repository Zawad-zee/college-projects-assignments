package ca.sheridancollege.prog39402.project.varghese991588959zawad991583646

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "simple")
data class SimpleUser (@PrimaryKey(autoGenerate = true)
                       var id:Long,
                       @ColumnInfo(name = "Name")
                       var name :String,
                       )
