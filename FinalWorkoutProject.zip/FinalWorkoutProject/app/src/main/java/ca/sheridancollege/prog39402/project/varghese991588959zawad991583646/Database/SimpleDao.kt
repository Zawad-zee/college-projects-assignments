package ca.sheridancollege.prog39402.project.varghese991588959zawad991583646

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface SimpleDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(student: SimpleUser)
    @Query("SELECT * FROM simple")
    fun getAll():List<SimpleUser>

}