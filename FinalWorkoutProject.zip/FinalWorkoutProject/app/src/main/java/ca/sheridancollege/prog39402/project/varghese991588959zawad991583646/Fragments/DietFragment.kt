package ca.sheridancollege.prog39402.project.varghese991588959zawad991583646

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.eu.fragmentstatemanager.StateManager
import sheridancollege.prog39402.Varghese991588959.Zawad991583646.DatabaseP

class DietFragment(var w:String,var user:String) : Fragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {val v=inflater.inflate(R.layout.fragment_diet, container, false)
        var recyclerView: RecyclerView
                recyclerView=v.findViewById(R.id.mealRecycler)
        val layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = layoutManager

        //initData();

        var myDB = DatabaseP.getInstance(this.requireActivity())
        var ourList= myDB.LoadedDietDao().getAll()
        //initData();

        recyclerView.adapter = MealRecyclerViewAdapter(ourList,requireContext(),user)
        //
        return v
    }

    fun test()
    {
        StateManager.getInstance().showOnNavigationClick(MainActivity.prediet, PrestoredDietFragment(w,user))
    }


}