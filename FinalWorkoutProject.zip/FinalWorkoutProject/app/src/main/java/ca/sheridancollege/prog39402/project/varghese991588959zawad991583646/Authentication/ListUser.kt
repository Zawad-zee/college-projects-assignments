package ca.sheridancollege.prog39402.project.varghese991588959zawad991583646

data class ListUser( val text1: String)